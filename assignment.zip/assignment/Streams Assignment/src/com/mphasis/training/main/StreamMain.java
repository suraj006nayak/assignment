package com.mphasis.training.main;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.mphasis.training.entity.Treatment;
import com.mphasis.training.entity.TreatmentTable1;
import com.mphasis.training.entity.TreatmentTable2;
import com.mphasis.training.exception.StreamsException;
import com.mphasis.training.services.Treatment1Service;
import com.mphasis.training.services.Treatment1ServiceImpl;
import com.mphasis.training.services.Treatment2Service;
import com.mphasis.training.services.Treatment2ServiceImpl;
import com.mphasis.training.services.Treatmentservice;
import com.mphasis.training.services.TreatmentserviceImpl;

public class StreamMain {

	public static void main(String[] args) throws StreamsException {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		Treatmentservice e=new TreatmentserviceImpl();
		Treatment1Service a=new Treatment1ServiceImpl();
		Treatment2Service d=new Treatment2ServiceImpl();
		
		do {
			System.out.println("1.Streams To get the Treatment list \n "
					+ "2.Streams To get the Treatment1 list."
					+ "\n 3.Streams to get first Treatment with payee Account name as Rekha"
					+ "\n 4.Streams To get the more than one account list  ."
					+ "\n 5.Exit ");
			
			switch(sc.nextInt())
			{
			case 1: System.out.println("Streams To get the Treatment list");
			  List<Treatment> treatments= e.getTreatmentdetails();
			  treatments.forEach((c)-> System.out.println(c.getId()+" "+c.getTreatmenttype()+ 
			 " " +c.getAccNo()+" "));
			  break;
			  
			case 2: System.out.println("Streams To get the Treatment list");
			  List<TreatmentTable1> treatments1= a.getTreatment1details();
			  treatments1.forEach((c)-> System.out.println(c.getAccNo()+" "+c. getHolidayStartDate()+ 
			 " " +c.getHolidayEndDate()+" "+c.getTreatment()));
			  break;
			  
			 case 3: System.out.println("Streams to get first Treatment with payee Account name as Rekha");
			  String PayeeAccountName=sc.next();
			  List<TreatmentTable2> Payee= d.getByPayeeAccountName()
					  .stream().filter((b)-> b.getPayeeAccountName()
							  .equalsIgnoreCase(PayeeAccountName))
							  .collect(Collectors.toList());
			  Payee.forEach(System.out::println);
				
					  break;
					  
			 case 4: System.out.println("Streams To get more than one account list");
			  List<Treatment> x= e.getTreatmentByAccNo();
			  x.forEach((c)-> System.out.println(c.getId()+" "+c.getTreatmenttype()+ 
			 " " +c.getAccNo()+" "));
			  List<TreatmentTable1> y= a.getTreatmentByAccNo();
			  y.forEach((f)-> System.out.println(f.getAccNo()+" "+f.getHolidayStartDate()+ 
			 " " +f.getHolidayEndDate()+" "+f.getTreatment()));
			  List<TreatmentTable2> z= d.getTreatmentByAccNo();
			  z.forEach((v)-> System.out.println(v.getAccNo()+" "+v.getPayeeAccountName()+ 
			 " " +v.getPayeeTerm()+" "));
			  break;
			  
			 case 5:System.out.println("Thank You");
			  sc.close();
			  System.exit(0);
			  
			
			  

			  default: System.out.println("invalid option");
			  }
		}while(true);
			  }

}
	
