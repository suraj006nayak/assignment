package com.mphasis.training.services;

import java.util.List;

import com.mphasis.training.entity.TreatmentTable2;
import com.mphasis.training.exception.StreamsException;

public interface Treatment2Service {
	
	public List<TreatmentTable2> getTreatment2details() throws StreamsException;
	public List<TreatmentTable2> getTreatmentByAccNo() throws StreamsException;
	public List<TreatmentTable2> getByPayeeAccountName() throws StreamsException;
	public List<TreatmentTable2> getByPayeeTerm() throws StreamsException;


}
