package com.mphasis.training.repos;

import java.util.List;

import com.mphasis.training.entity.Treatment;

public class TreatmentrepoImpl implements Treatmentrepo {

	@Override
	public List<Treatment> getTreatmentdetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Treatment getTreatmentById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Treatment> getTreatmentByTreatmenttype() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Treatment> getTreatmentByAccNo() {
		// TODO Auto-generated method stub
		return null;
	}

}
