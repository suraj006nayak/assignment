package com.mphasis.training.repos;

import java.util.List;

import com.mphasis.training.entity.TreatmentTable1;

public class Treatment1repoImpl implements Treatment1repo {

	@Override
	public List<TreatmentTable1> getTreatment1details() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TreatmentTable1> getTreatmentByAccNo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TreatmentTable1> getByHolidayStartDate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TreatmentTable1> getByHolidayEndDate() {
		// TODO Auto-generated method stub
		return null;
	}

}
